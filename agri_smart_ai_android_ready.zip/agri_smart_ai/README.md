# AgriSmart AI – Smart Agriculture Assistant

A final-year-project-ready full-stack agriculture assistant with a Flutter Android app and Python FastAPI backend.

## Mobile flow

Splash → Login/Register → Home Dashboard → AI Tools / Weather / History / Profile

AI Tools:
- Plant disease image detection
- Crop recommendation
- Fertilizer advisor
- Irrigation assistant
- AgriBot chatbot

## 1. Requirements

Install:
- Flutter 3.24+ (Dart 3.5+ recommended)
- Android Studio with Android SDK 35
- Android SDK Platform Tools
- Java 17
- Python 3.11+

Run `flutter doctor` and fix any Android toolchain issues before building.

## 2. Configure Android

The repository contains the Android project files. Flutter normally creates `android/local.properties` automatically. If it is missing, create it from `mobile_app/android/local.properties.example` and set the real Flutter SDK and Android SDK paths.

## 3. Run backend

```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn backend.main:app --reload --host 0.0.0.0 --port 8000
```

API docs: http://127.0.0.1:8000/docs

Seed the demo account:

```bash
python backend/seed_demo.py
```

Demo account:
- Email: farmer@demo.local
- Password: Farmer@123

## 4. Connect Flutter to FastAPI

### Android emulator

Use:

```bash
flutter run --dart-define=API_URL=http://10.0.2.2:8000
```

`10.0.2.2` maps from the Android emulator to your computer's localhost.

### Physical Android phone

Run the backend on your computer's LAN interface and use your computer's LAN IP, for example:

```bash
flutter run --dart-define=API_URL=http://192.168.1.10:8000
```

The phone and computer must be on the same Wi-Fi network.

## 5. Build release APK

From `mobile_app/`:

```bash
flutter pub get
flutter analyze
flutter build apk --release --dart-define=API_URL=http://YOUR_SERVER_IP:8000
```

Output:

`mobile_app/build/app/outputs/flutter-apk/app-release.apk`

There is also `scripts/build_apk.sh` and `scripts/build_apk.bat` for repeatable builds.

### Note about this delivery environment

The source is Android/Flutter-ready, but the current coding environment does not contain the Flutter SDK, Android SDK or Gradle wrapper binary, so an APK binary cannot be compiled here. On a machine with Flutter + Android Studio installed, the commands above build the APK.

If Android Studio/Flutter reports missing platform files, run this once inside `mobile_app`:

```bash
flutter create --platforms=android .
```

Then keep the Dart source, `pubspec.yaml`, permissions and API configuration from this project. This is only a platform regeneration step for machines whose Flutter installation expects its own generated wrapper files.

## 6. ML models

Crop recommendation uses the included Scikit-learn training pipeline. Disease detection contains the Keras training/loading structure and a clearly marked demo inference fallback when a trained model artifact is not present.

Train the crop model:

```bash
python ml_models/crop_model/train.py
```

For real disease detection, train using a properly labelled plant-leaf image dataset and place the resulting Keras model where `backend/ai/disease.py` expects it.

## 7. Backend database

Default: SQLite (`agri_smart.db`). PostgreSQL/MySQL can be configured with `DATABASE_URL`.

Schema: `database/schema.sql`

## 8. API endpoints

- POST `/register`
- POST `/login`
- GET `/profile`
- PUT `/profile`
- POST `/crop-recommendation`
- POST `/disease-detection`
- POST `/fertilizer-recommendation`
- POST `/irrigation-advice`
- POST `/weather`
- POST `/chat`
- GET `/history`
- GET `/notifications`
- GET `/admin/stats`
- GET `/admin/farmers`

## 9. Security

- Passwords are hashed by the backend.
- JWT access tokens are stored using Flutter secure storage.
- Image uploads are restricted to JPG/PNG/WEBP and 8 MB.
- Backend input validation uses Pydantic constraints.
- Release signing should use your own Android keystore before publishing.

## 10. Final-year demonstration sequence

1. Launch app and show AgriSmart AI splash screen.
2. Register/login.
3. Show dashboard and live weather.
4. Open AI Tools.
5. Demonstrate crop recommendation with NPK/pH values.
6. Demonstrate fertilizer recommendation.
7. Demonstrate irrigation advice.
8. Capture/select a leaf image and show disease result.
9. Ask AgriBot a farming question.
10. Open History and show saved recommendations.
11. Edit Farm Profile.
12. Open FastAPI `/docs` and demonstrate the REST API.
13. Show the ER/architecture diagrams during viva.
