@echo off
cd /d "%~dp0..\mobile_app"
where flutter >nul 2>nul
if errorlevel 1 (
  echo Flutter SDK was not found. Install Flutter and Android Studio first.
  exit /b 1
)
flutter pub get
flutter analyze
flutter build apk --release --dart-define=API_URL=%API_URL%
echo APK: build\app\outputs\flutter-apk\app-release.apk
