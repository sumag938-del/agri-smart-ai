#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/../mobile_app"
if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter SDK was not found. Install Flutter and Android Studio first."
  exit 1
fi
flutter pub get
flutter analyze
flutter build apk --release --dart-define=API_URL="${API_URL:-http://10.0.2.2:8000}"
echo "APK: build/app/outputs/flutter-apk/app-release.apk"
