import 'package:flutter/material.dart';

const green = Color(0xFF237A35);
const greenDark = Color(0xFF12451E);
const lightGreen = Color(0xFFE8F5E8);
const mint = Color(0xFFF4FAF2);
const dark = Color(0xFF17351D);
const amber = Color(0xFFFFA000);
const red = Color(0xFFC62828);

InputDecoration input(String label, {IconData? icon, String? hint, Widget? suffixIcon}) => InputDecoration(
      labelText: label,
      hintText: hint,
      prefixIcon: icon == null ? null : Icon(icon, color: green),
      suffixIcon: suffixIcon,
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: green, width: 1.2)),
      errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: red)),
    );

class AppCard extends StatelessWidget {
  final Widget child;
  final VoidCallback? onTap;
  final EdgeInsets padding;
  final Color color;

  const AppCard({super.key, required this.child, this.onTap, this.padding = const EdgeInsets.all(16), this.color = Colors.white});

  @override
  Widget build(BuildContext context) => Card(
        margin: EdgeInsets.zero,
        elevation: 0,
        color: color,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22), side: BorderSide(color: Colors.black.withOpacity(.045))),
        child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(22), child: Padding(padding: padding, child: child)),
      );
}

class FeatureCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final Color iconBackground;

  const FeatureCard({super.key, required this.icon, required this.title, required this.subtitle, required this.onTap, this.iconBackground = lightGreen});

  @override
  Widget build(BuildContext context) => AppCard(
        onTap: onTap,
        child: Row(children: [
          Container(width: 52, height: 52, decoration: BoxDecoration(color: iconBackground, borderRadius: BorderRadius.circular(16)), child: Icon(icon, color: green, size: 26)),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontSize: 15.5, fontWeight: FontWeight.w800, color: dark)),
            const SizedBox(height: 4),
            Text(subtitle, style: TextStyle(fontSize: 12.5, color: Colors.grey[650], height: 1.3)),
          ])),
          const Icon(Icons.chevron_right_rounded, color: Colors.grey),
        ]),
      );
}

class SectionTitle extends StatelessWidget {
  final String title;
  final String? action;
  final VoidCallback? onTap;
  const SectionTitle({super.key, required this.title, this.action, this.onTap});

  @override
  Widget build(BuildContext context) => Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: dark)),
        if (action != null) TextButton(onPressed: onTap, child: Text(action!, style: const TextStyle(color: green))),
      ]);
}

class StatPill extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;
  const StatPill({super.key, required this.icon, required this.value, required this.label});

  @override
  Widget build(BuildContext context) => Expanded(child: Container(
        padding: const EdgeInsets.all(11),
        decoration: BoxDecoration(color: mint, borderRadius: BorderRadius.circular(16)),
        child: Row(children: [
          Icon(icon, color: green, size: 20),
          const SizedBox(width: 7),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(value, style: const TextStyle(fontWeight: FontWeight.w800, color: dark)),
            Text(label, style: const TextStyle(fontSize: 10, color: Colors.grey)),
          ])),
        ]),
      ));
}

class LoadingButton extends StatelessWidget {
  final bool busy;
  final String label;
  final VoidCallback? onPressed;
  final IconData icon;
  const LoadingButton({super.key, required this.busy, required this.label, required this.onPressed, this.icon = Icons.auto_awesome});

  @override
  Widget build(BuildContext context) => SizedBox(
        height: 52,
        width: double.infinity,
        child: FilledButton.icon(
          onPressed: busy ? null : onPressed,
          icon: busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : Icon(icon),
          label: Text(busy ? 'Processing…' : label),
        ),
      );
}

void showError(BuildContext context, Object error) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
    behavior: SnackBarBehavior.floating,
    content: Text(error.toString().replaceFirst('Exception: ', '')),
  ));
}
