import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import '../services/api.dart';
import '../widgets/common.dart';

class HomeScreen extends StatefulWidget {
  final ValueChanged<int> onNavigate;
  const HomeScreen({super.key, required this.onNavigate});
  @override State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String farmerName = 'Farmer';
  String location = 'Hyderabad';
  Map<String, dynamic>? weather;
  bool loading = true;
  List<dynamic> alerts = [];

  @override
  void initState() { super.initState(); load(); }

  Future<Position?> _location() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) return null;
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) return null;
      return Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.medium));
    } catch (_) { return null; }
  }

  Future<void> load() async {
    if (mounted) setState(() => loading = true);
    try {
      final profile = await ApiService.profile();
      farmerName = (profile['name'] ?? 'Farmer').toString();
      location = (profile['location'] ?? 'Hyderabad').toString();
    } catch (_) {}
    final position = await _location();
    final lat = position?.latitude ?? 17.3850;
    final lon = position?.longitude ?? 78.4867;
    try {
      weather = await ApiService.weather(lat, lon, position == null ? location : 'Current location');
    } catch (_) {}
    try { alerts = await ApiService.notifications(); } catch (_) {}
    if (mounted) setState(() => loading = false);
  }

  void openTools() => widget.onNavigate(1);
  void openWeather() => widget.onNavigate(2);
  void openHistory() => widget.onNavigate(3);

  @override
  Widget build(BuildContext context) => RefreshIndicator(
    onRefresh: load,
    child: ListView(padding: const EdgeInsets.fromLTRB(18, 20, 18, 100), children: [
      Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Good morning, $farmerName 👋', style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: dark)),
          const SizedBox(height: 5),
          const Text('Let AI help you farm smarter today', style: TextStyle(color: Colors.grey)),
        ])),
        Stack(children: [IconButton(onPressed: () => _showNotifications(context), icon: const Icon(Icons.notifications_none_rounded, color: green)), if (alerts.any((x) => x['read'] == false)) Positioned(right: 9, top: 8, child: Container(width: 8, height: 8, decoration: const BoxDecoration(color: red, shape: BoxShape.circle)))])
      ]),
      const SizedBox(height: 18),
      AppCard(child: Container(
        padding: const EdgeInsets.all(19),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF2F8B3E), Color(0xFF17662A)])),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [const Icon(Icons.auto_awesome_rounded, color: Colors.white), const SizedBox(width: 8), const Text('FARM INTELLIGENCE', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1.1))]),
          const SizedBox(height: 11),
          const Text('Better decisions.\nHealthier crops.', style: TextStyle(color: Colors.white, fontSize: 24, height: 1.12, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          Text('AI guidance for soil, crops, weather and disease care.', style: TextStyle(color: Colors.white.withOpacity(.84))),
          const SizedBox(height: 15),
          FilledButton(onPressed: openTools, style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: green), child: const Text('Explore AI Tools')),
        ]),
      )),
      const SizedBox(height: 20),
      SectionTitle(title: 'Today on your farm', action: loading ? 'Updating…' : 'Refresh', onTap: load),
      const SizedBox(height: 9),
      AppCard(onTap: openWeather, child: Column(children: [
        Row(children: [
          Container(width: 52, height: 52, decoration: BoxDecoration(color: lightGreen, borderRadius: BorderRadius.circular(16)), child: const Icon(Icons.wb_sunny_rounded, color: green, size: 28)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(weather?['condition']?.toString() ?? 'Weather unavailable', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: dark)), Text(location, style: const TextStyle(color: Colors.grey))])),
          Text(weather == null ? '--' : '${weather!['temperature']}°', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: dark)),
        ]),
        const SizedBox(height: 15),
        Row(children: [
          StatPill(icon: Icons.water_drop_outlined, value: weather == null ? '--' : '${weather!['humidity']}%', label: 'Humidity'),
          const SizedBox(width: 8),
          StatPill(icon: Icons.umbrella_outlined, value: weather == null ? '--' : '${weather!['rain_probability']}%', label: 'Rain chance'),
          const SizedBox(width: 8),
          StatPill(icon: Icons.air, value: weather == null ? '--' : '${weather!['wind_speed']}', label: 'Wind km/h'),
        ]),
      ])),
      const SizedBox(height: 20),
      const SectionTitle(title: 'Quick AI actions'),
      const SizedBox(height: 10),
      GridView.count(crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1.48, children: [
        _Quick(icon: Icons.document_scanner_rounded, title: 'Disease Scan', onTap: openTools),
        _Quick(icon: Icons.grass_rounded, title: 'Crop Advisor', onTap: openTools),
        _Quick(icon: Icons.science_rounded, title: 'Fertilizer', onTap: openTools),
        _Quick(icon: Icons.water_drop_rounded, title: 'Irrigation', onTap: openTools),
      ]),
      const SizedBox(height: 18),
      AppCard(onTap: openTools, child: Row(children: [
        Container(width: 50, height: 50, decoration: BoxDecoration(color: lightGreen, borderRadius: BorderRadius.circular(16)), child: const Icon(Icons.smart_toy_rounded, color: green, size: 27)),
        const SizedBox(width: 12),
        const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Ask AgriBot', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: dark)), SizedBox(height: 3), Text('Get simple answers for everyday farm questions', style: TextStyle(fontSize: 12.5, color: Colors.grey))])),
        const Icon(Icons.arrow_forward_rounded, color: green),
      ])),
      const SizedBox(height: 18),
      AppCard(onTap: openHistory, child: Row(children: [const Icon(Icons.history_rounded, color: green), const SizedBox(width: 10), const Expanded(child: Text('Review your previous AI recommendations', style: TextStyle(fontWeight: FontWeight.w700, color: dark))), const Icon(Icons.chevron_right_rounded, color: Colors.grey)])),
    ]),
  );

  void _showNotifications(BuildContext context) {
    showModalBottomSheet(context: context, isScrollControlled: true, showDragHandle: true, builder: (_) => SafeArea(child: SizedBox(height: 480, child: Padding(padding: const EdgeInsets.fromLTRB(18, 4, 18, 18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Farm alerts', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: dark)),
      const SizedBox(height: 12),
      Expanded(child: alerts.isEmpty ? const Center(child: Text('No new alerts')) : ListView.separated(itemCount: alerts.length, separatorBuilder: (_, __) => const SizedBox(height: 8), itemBuilder: (_, i) { final x = alerts[i]; return AppCard(child: ListTile(contentPadding: EdgeInsets.zero, leading: const CircleAvatar(backgroundColor: lightGreen, child: Icon(Icons.notifications_active_outlined, color: green)), title: Text('${x['title']}', style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text('${x['body']}')); })),
    ])))));
  }
}

class _Quick extends StatelessWidget {
  final IconData icon; final String title; final VoidCallback onTap;
  const _Quick({required this.icon, required this.title, required this.onTap});
  @override Widget build(BuildContext context) => AppCard(onTap: onTap, child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: green, size: 28), const SizedBox(height: 9), Text(title, style: const TextStyle(fontWeight: FontWeight.w800, color: dark))]));
}
