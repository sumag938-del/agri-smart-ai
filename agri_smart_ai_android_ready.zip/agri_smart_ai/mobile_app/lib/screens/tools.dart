import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../services/api.dart';
import '../widgets/common.dart';

class ToolsScreen extends StatelessWidget {
  const ToolsScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.fromLTRB(18, 20, 18, 100), children: [
    const Text('AI Tools', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900, color: dark)),
    const SizedBox(height: 5),
    Text('Practical intelligence for everyday farming', style: TextStyle(color: Colors.grey[700])),
    const SizedBox(height: 18),
    FeatureCard(icon: Icons.document_scanner_rounded, title: 'Disease Detection', subtitle: 'Scan a leaf with camera or gallery and get a structured AI result.', onTap: () => _open(context, const DiseaseScreen())),
    const SizedBox(height: 10),
    FeatureCard(icon: Icons.grass_rounded, title: 'Crop Recommendation', subtitle: 'Use NPK, pH and climate values to find a suitable crop.', onTap: () => _open(context, const CropScreen())),
    const SizedBox(height: 10),
    FeatureCard(icon: Icons.science_rounded, title: 'Fertilizer Advisor', subtitle: 'Get nutrient guidance based on crop, soil and growth stage.', onTap: () => _open(context, const FertScreen())),
    const SizedBox(height: 10),
    FeatureCard(icon: Icons.water_drop_rounded, title: 'Irrigation Assistant', subtitle: 'Estimate whether your crop needs water using moisture and rain.', onTap: () => _open(context, const IrrScreen())),
    const SizedBox(height: 10),
    FeatureCard(icon: Icons.smart_toy_rounded, title: 'AgriBot', subtitle: 'Ask questions about crops, disease, irrigation and farm care.', onTap: () => _open(context, const ChatScreen())),
  ]);

  static void _open(BuildContext context, Widget page) => Navigator.push(context, MaterialPageRoute(builder: (_) => page));
}

class FormPage extends StatefulWidget {
  final String title;
  final List<Widget> children;
  final Future<void> Function()? action;
  final Widget? result;
  final String button;
  const FormPage({super.key, required this.title, required this.children, this.action, this.result, this.button = 'Get AI Recommendation'});
  @override State<FormPage> createState() => _FormPageState();
}

class _FormPageState extends State<FormPage> {
  bool busy = false;
  Future<void> run() async {
    FocusScope.of(context).unfocus();
    setState(() => busy = true);
    try { await widget.action?.call(); } catch (e) { if (mounted) showError(context, e); }
    if (mounted) setState(() => busy = false);
  }
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(widget.title)), body: ListView(padding: const EdgeInsets.fromLTRB(18, 6, 18, 30), children: [
    ...widget.children,
    if (widget.action != null) ...[const SizedBox(height: 8), LoadingButton(busy: busy, label: widget.button, onPressed: run)],
    if (widget.result != null) Padding(padding: const EdgeInsets.only(top: 18), child: widget.result!),
  ]));
}

TextField numberField(TextEditingController controller, String label, {IconData? icon}) => Padding(padding: const EdgeInsets.only(bottom: 10), child: TextField(controller: controller, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: input(label, icon: icon)));
TextField textField(TextEditingController controller, String label, {IconData? icon}) => Padding(padding: const EdgeInsets.only(bottom: 10), child: TextField(controller: controller, decoration: input(label, icon: icon)));

class CropScreen extends StatefulWidget { const CropScreen({super.key}); @override State<CropScreen> createState() => _CropScreenState(); }
class _CropScreenState extends State<CropScreen> {
  final n = TextEditingController(text: '70'), p = TextEditingController(text: '40'), k = TextEditingController(text: '40'), ph = TextEditingController(text: '6.5'), t = TextEditingController(text: '28'), h = TextEditingController(text: '70'), r = TextEditingController(text: '120');
  Map<String, dynamic>? result;
  @override void dispose() { for (final x in [n,p,k,ph,t,h,r]) x.dispose(); super.dispose(); }
  Future<void> run() async { result = await ApiService.crop({'n': double.parse(n.text), 'p': double.parse(p.text), 'k': double.parse(k.text), 'ph': double.parse(ph.text), 'temperature': double.parse(t.text), 'humidity': double.parse(h.text), 'rainfall': double.parse(r.text)}); setState(() {}); }
  @override Widget build(BuildContext context) => FormPage(title: 'Crop Recommendation', button: 'Recommend Crop', action: run, children: [numberField(n,'Nitrogen (N)',icon:Icons.science_outlined), numberField(p,'Phosphorus (P)',icon:Icons.science_outlined), numberField(k,'Potassium (K)',icon:Icons.science_outlined), numberField(ph,'Soil pH',icon:Icons.opacity), numberField(t,'Temperature °C',icon:Icons.thermostat), numberField(h,'Humidity %',icon:Icons.water_drop_outlined), numberField(r,'Rainfall mm',icon:Icons.umbrella_outlined)], result: result == null ? null : AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('AI recommendation', style: TextStyle(color: green, fontWeight: FontWeight.w800)), const SizedBox(height: 6), Text('${result!['crop']}', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: dark)), const SizedBox(height: 4), Text('Confidence ${result!['confidence']}%', style: const TextStyle(fontWeight: FontWeight.w700)), const Divider(height: 24), Text('${result!['reason']}')])));
}

class FertScreen extends StatefulWidget { const FertScreen({super.key}); @override State<FertScreen> createState() => _FertScreenState(); }
class _FertScreenState extends State<FertScreen> {
  final crop=TextEditingController(text:'Rice'), soil=TextEditingController(text:'Loamy'), n=TextEditingController(text:'40'), p=TextEditingController(text:'30'), k=TextEditingController(text:'35'), ph=TextEditingController(text:'6.5'), stage=TextEditingController(text:'Vegetative'); Map<String,dynamic>? result;
  @override void dispose(){for(final x in [crop,soil,n,p,k,ph,stage])x.dispose();super.dispose();}
  Future<void> run() async { result=await ApiService.fertilizer({'crop':crop.text.trim(),'soil_type':soil.text.trim(),'n':double.parse(n.text),'p':double.parse(p.text),'k':double.parse(k.text),'ph':double.parse(ph.text),'stage':stage.text.trim()});setState((){}); }
  @override Widget build(BuildContext context)=>FormPage(title:'Fertilizer Advisor',button:'Get Fertilizer Advice',action:run,children:[textField(crop,'Crop',icon:Icons.grass),textField(soil,'Soil type',icon:Icons.landscape),numberField(n,'Nitrogen N'),numberField(p,'Phosphorus P'),numberField(k,'Potassium K'),numberField(ph,'Soil pH'),textField(stage,'Growth stage',icon:Icons.timeline)],result:result==null?null:AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('${result!['fertilizer']}',style:const TextStyle(fontSize:21,fontWeight:FontWeight.w900,color:dark)),const SizedBox(height:8),Text('${result!['reason']}'),const SizedBox(height:10),Text('${result!['guidance']}',style:const TextStyle(fontWeight:FontWeight.w700))])));
}

class IrrScreen extends StatefulWidget { const IrrScreen({super.key}); @override State<IrrScreen> createState()=>_IrrScreenState(); }
class _IrrScreenState extends State<IrrScreen>{final m=TextEditingController(text:'35'),t=TextEditingController(text:'31'),h=TextEditingController(text:'65'),r=TextEditingController(text:'10'),crop=TextEditingController(text:'Rice');String?result;@override void dispose(){for(final x in [m,t,h,r,crop])x.dispose();super.dispose();}Future<void>run()async{final x=await ApiService.irrigation({'soil_moisture':double.parse(m.text),'temperature':double.parse(t.text),'humidity':double.parse(h.text),'rainfall':double.parse(r.text),'crop':crop.text.trim()});setState(()=>result=x['advice']?.toString());}@override Widget build(BuildContext context)=>FormPage(title:'Irrigation Assistant',button:'Check Water Need',action:run,children:[numberField(m,'Soil moisture %',icon:Icons.water_drop),numberField(t,'Temperature °C',icon:Icons.thermostat),numberField(h,'Humidity %',icon:Icons.opacity),numberField(r,'Expected rain mm',icon:Icons.umbrella),textField(crop,'Crop',icon:Icons.grass)],result:result==null?null:AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Icon(Icons.water_drop_rounded,color:green,size:30),const SizedBox(height:8),Text(result!,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w800,color:dark))])));}

class DiseaseScreen extends StatefulWidget { const DiseaseScreen({super.key}); @override State<DiseaseScreen> createState()=>_DiseaseScreenState(); }
class _DiseaseScreenState extends State<DiseaseScreen>{final picker=ImagePicker();File? image;Map<String,dynamic>?result;bool busy=false;
  Future<void> pick(ImageSource source)async{try{final x=await picker.pickImage(source:source,maxWidth:1600,imageQuality:88);if(x!=null)setState(()=>image=File(x.path));}catch(e){if(mounted)showError(context,e);}}
  Future<void> scan()async{if(image==null)return;setState(()=>busy=true);try{result=await ApiService.disease(image!);setState((){});}catch(e){if(mounted)showError(context,e);}finally{if(mounted)setState(()=>busy=false);}}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Disease Detection')),body:ListView(padding:const EdgeInsets.fromLTRB(18,6,18,30),children:[
    Container(height:250,clipBehavior:Clip.antiAlias,decoration:BoxDecoration(color:lightGreen,borderRadius:BorderRadius.circular(24)),child:image==null?Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(Icons.eco_rounded,size:72,color:green.withOpacity(.5)),const SizedBox(height:8),const Text('Upload a clear crop leaf photo',style:TextStyle(fontWeight:FontWeight.w800,color:dark)),const SizedBox(height:3),const Text('JPG, PNG or WEBP • max 8 MB',style:TextStyle(color:Colors.grey,fontSize:12))]):Image.file(image!,fit:BoxFit.cover,width:double.infinity)),
    const SizedBox(height:14),Row(children:[Expanded(child:OutlinedButton.icon(onPressed:busy?null:()=>pick(ImageSource.camera),icon:const Icon(Icons.camera_alt_rounded),label:const Text('Camera'))),const SizedBox(width:10),Expanded(child:OutlinedButton.icon(onPressed:busy?null:()=>pick(ImageSource.gallery),icon:const Icon(Icons.photo_library_rounded),label:const Text('Gallery')))]),const SizedBox(height:8),LoadingButton(busy:busy,label:'Analyze with AI',onPressed:scan),
    if(result!=null)Padding(padding:const EdgeInsets.only(top:18),child:AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Container(padding:const EdgeInsets.symmetric(horizontal:10,vertical:6),decoration:BoxDecoration(color:lightGreen,borderRadius:BorderRadius.circular(20)),child:Text('${result!['confidence']}% confidence',style:const TextStyle(color:green,fontWeight:FontWeight.w800))),const Spacer(),Text('${result!['crop']}',style:const TextStyle(color:green,fontWeight:FontWeight.w800))]),const SizedBox(height:10),Text('${result!['disease']}',style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900,color:dark)),const Divider(height:26),InfoBlock('Symptoms',result!['symptoms']),InfoBlock('Possible causes',result!['causes']),InfoBlock('Recommended treatment',result!['treatment']),InfoBlock('Prevention',result!['prevention']),if(result!['demo']==true)const Padding(padding:EdgeInsets.only(top:8),child:Text('Demo model active. Replace the model artifact with a trained Keras classifier before claiming real-world accuracy.',style:TextStyle(fontStyle:FontStyle.italic,fontSize:11,color:Colors.grey))) ])))
  ]);}
class InfoBlock extends StatelessWidget{final String title;final dynamic value;const InfoBlock(this.title,this.value,{super.key});@override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.only(bottom:11),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontWeight:FontWeight.w800,color:dark)),const SizedBox(height:3),Text('$value',style:const TextStyle(height:1.35))]));}

class ChatScreen extends StatefulWidget { const ChatScreen({super.key}); @override State<ChatScreen> createState()=>_ChatScreenState(); }
class _ChatScreenState extends State<ChatScreen>{final q=TextEditingController();final scroll=ScrollController();final messages=<Map<String,String>>[{'bot':'Hello! I’m AgriBot 🌱\nAsk me about crops, soil, irrigation, fertilizer or disease care.'}];bool busy=false;
  @override void dispose(){q.dispose();scroll.dispose();super.dispose();}
  Future<void> send()async{final text=q.text.trim();if(text.isEmpty||busy)return;q.clear();setState((){messages.add({'me':text});busy=true;});try{final x=await ApiService.chat(text);if(mounted)setState(()=>messages.add({'bot':x['response']?.toString()??'No response received.'}));}catch(e){if(mounted)setState(()=>messages.add({'bot':'I could not reach the server. Check the backend URL and connection.'}));}finally{if(mounted){setState(()=>busy=false);WidgetsBinding.instance.addPostFrameCallback((_){if(scroll.hasClients)scroll.animateTo(scroll.position.maxScrollExtent,duration:const Duration(milliseconds:250),curve:Curves.easeOut);});}}}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Row(children:[Container(width:36,height:36,decoration:BoxDecoration(color:lightGreen,borderRadius:BorderRadius.circular(11)),child:const Icon(Icons.smart_toy_rounded,color:green,size:21)),const SizedBox(width:9),const Text('AgriBot',style:TextStyle(fontWeight:FontWeight.w800))])),body:Column(children:[Expanded(child:ListView(controller:scroll,padding:const EdgeInsets.all(14),children:messages.map((m){final me=m.containsKey('me');return Align(alignment:me?Alignment.centerRight:Alignment.centerLeft,child:Container(margin:const EdgeInsets.only(bottom:10),padding:const EdgeInsets.all(13),constraints:const BoxConstraints(maxWidth:340),decoration:BoxDecoration(color:me?green:Colors.white,borderRadius:BorderRadius.circular(18),border:me?null:Border.all(color:Colors.black12)),child:Text(me?m['me']!:m['bot']!,style:TextStyle(color:me?Colors.white:dark,height:1.35)));}).toList())),SafeArea(top:false,child:Container(padding:const EdgeInsets.fromLTRB(12,8,12,12),color:mint,child:Row(crossAxisAlignment:CrossAxisAlignment.end,children:[Expanded(child:TextField(controller:q,minLines:1,maxLines:4,textInputAction:TextInputAction.send,onSubmitted:(_)=>send(),decoration:input('Ask about your farm'))),const SizedBox(width:7),CircleAvatar(backgroundColor:green,child:IconButton(onPressed:busy?null:send,icon:const Icon(Icons.send_rounded,color:Colors.white))) ]))) ]));}
