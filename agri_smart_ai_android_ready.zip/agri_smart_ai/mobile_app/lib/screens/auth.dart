import 'package:flutter/material.dart';
import '../services/api.dart';
import '../widgets/common.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final formKey = GlobalKey<FormState>();
  final name = TextEditingController();
  final identifier = TextEditingController();
  final password = TextEditingController();
  bool register = false;
  bool busy = false;
  bool obscure = true;

  @override
  void dispose() { name.dispose(); identifier.dispose(); password.dispose(); super.dispose(); }

  Future<void> submit() async {
    if (!(formKey.currentState?.validate() ?? false)) return;
    setState(() => busy = true);
    try {
      final result = register
          ? await ApiService.register(name.text.trim(), identifier.text.trim(), password.text)
          : await ApiService.login(identifier.text.trim(), password.text);
      await ApiService.saveToken(result['access_token'].toString());
      if (!mounted) return;
      Navigator.pushReplacementNamed(context, '/app');
    } catch (e) {
      if (mounted) showError(context, e);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  String? requiredField(String? value, String label) => value == null || value.trim().isEmpty ? '$label is required' : null;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(24, 36, 24, 24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 520),
              child: Form(
                key: formKey,
                child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  Center(child: Container(
                    width: 82, height: 82,
                    decoration: BoxDecoration(color: green, borderRadius: BorderRadius.circular(26), boxShadow: [BoxShadow(color: green.withOpacity(.20), blurRadius: 24, offset: const Offset(0, 10))]),
                    child: const Icon(Icons.agriculture_rounded, size: 46, color: Colors.white),
                  )),
                  const SizedBox(height: 18),
                  const Text('AgriSmart AI', textAlign: TextAlign.center, style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, color: dark)),
                  const SizedBox(height: 5),
                  const Text('Smart Farming with Artificial Intelligence', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
                  const SizedBox(height: 28),
                  AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    Text(register ? 'Create your farmer account' : 'Welcome back', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: dark)),
                    const SizedBox(height: 5),
                    Text(register ? 'Set up your profile to start using AI farm tools.' : 'Sign in to access your farm intelligence dashboard.', style: TextStyle(color: Colors.grey[700])),
                    const SizedBox(height: 22),
                    if (register) ...[
                      TextFormField(controller: name, decoration: input('Farmer name', icon: Icons.person_outline_rounded), validator: (v) => requiredField(v, 'Name')),
                      const SizedBox(height: 12),
                    ],
                    TextFormField(controller: identifier, keyboardType: TextInputType.emailAddress, decoration: input('Email or mobile number', icon: Icons.alternate_email_rounded), validator: (v) => requiredField(v, 'Email/mobile')),
                    const SizedBox(height: 12),
                    TextFormField(controller: password, obscureText: obscure, decoration: input('Password', icon: Icons.lock_outline_rounded, suffixIcon: IconButton(onPressed: () => setState(() => obscure = !obscure), icon: Icon(obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined))), validator: (v) {
                      if (v == null || v.isEmpty) return 'Password is required';
                      if (v.length < 6) return 'Use at least 6 characters';
                      return null;
                    }),
                    if (!register) Align(alignment: Alignment.centerRight, child: TextButton(onPressed: () => _forgot(context), child: const Text('Forgot password?'))),
                    const SizedBox(height: 8),
                    LoadingButton(busy: busy, label: register ? 'Create Account' : 'Login', onPressed: submit, icon: register ? Icons.person_add_alt_1_rounded : Icons.login_rounded),
                    const SizedBox(height: 8),
                    TextButton(onPressed: busy ? null : () => setState(() => register = !register), child: Text(register ? 'Already have an account? Login' : 'New to AgriSmart? Create account')),
                  ])),
                  const SizedBox(height: 18),
                  const Row(children: [Expanded(child: Divider()), Padding(padding: EdgeInsets.symmetric(horizontal: 10), child: Text('Secure access', style: TextStyle(color: Colors.grey, fontSize: 12))), Expanded(child: Divider())]),
                  const SizedBox(height: 10),
                  const Text('Your password is never stored as plain text. Authentication is handled by the FastAPI backend.', textAlign: TextAlign.center, style: TextStyle(fontSize: 11.5, color: Colors.grey)),
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _forgot(BuildContext context) {
    showDialog(context: context, builder: (_) => AlertDialog(
      title: const Text('Password reset'),
      content: const Text('Connect this flow to your email/SMS provider for production. For the project demo, use the registered account credentials.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
    ));
  }
}
