import 'dart:async';
import 'package:flutter/material.dart';
import '../services/api.dart';
import '../widgets/common.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(milliseconds: 1500), _openNext);
  }

  Future<void> _openNext() async {
    final token = await ApiService.token();
    if (!mounted) return;
    Navigator.pushReplacementNamed(context, token == null ? '/auth' : '/app');
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: green,
    body: Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Container(width: 104, height: 104, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(32)), child: const Icon(Icons.agriculture_rounded, size: 62, color: green)),
      const SizedBox(height: 24),
      const Text('AgriSmart AI', style: TextStyle(color: Colors.white, fontSize: 36, fontWeight: FontWeight.w900)),
      const SizedBox(height: 8),
      const Text('Smart Farming with Artificial Intelligence', textAlign: TextAlign.center, style: TextStyle(color: Colors.white70, fontSize: 14)),
      const SizedBox(height: 34),
      const SizedBox(width: 26, height: 26, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)),
    ])),
  );
}
