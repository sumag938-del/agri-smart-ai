import 'dart:convert';
import 'dart:io';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

class ApiService {
  static const baseUrl = String.fromEnvironment('API_URL', defaultValue: 'http://10.0.2.2:8000');
  static const _storage = FlutterSecureStorage();

  static Future<void> saveToken(String token) => _storage.write(key: 'token', value: token);
  static Future<String?> token() => _storage.read(key: 'token');
  static Future<void> logout() => _storage.delete(key: 'token');

  static Future<Map<String, dynamic>> _json(String method, String path, {Map<String, dynamic>? body}) async {
    final token = await ApiService.token();
    final headers = <String, String>{
      'Content-Type': 'application/json',
      if (token != null) 'Authorization': 'Bearer $token',
    };
    final uri = Uri.parse('$baseUrl$path');
    late http.Response response;
    if (method == 'GET') {
      response = await http.get(uri, headers: headers).timeout(const Duration(seconds: 20));
    } else if (method == 'PUT') {
      response = await http.put(uri, headers: headers, body: jsonEncode(body)).timeout(const Duration(seconds: 20));
    } else {
      response = await http.post(uri, headers: headers, body: jsonEncode(body)).timeout(const Duration(seconds: 20));
    }
    if (response.statusCode < 200 || response.statusCode >= 300) throw Exception(_message(response));
    return jsonDecode(response.body) as Map<String, dynamic>;
  }

  static String _message(http.Response response) {
    try {
      final data = jsonDecode(response.body);
      return data['detail']?.toString() ?? 'Request failed (${response.statusCode})';
    } catch (_) {
      return 'Request failed (${response.statusCode})';
    }
  }

  static Future<Map<String, dynamic>> login(String identifier, String password) => _json('POST', '/login', body: {'identifier': identifier, 'password': password});
  static Future<Map<String, dynamic>> register(String name, String identifier, String password) => _json('POST', '/register', body: {
        'name': name,
        'email': identifier.contains('@') ? identifier : null,
        'phone': identifier.contains('@') ? null : identifier,
        'password': password,
      });
  static Future<Map<String, dynamic>> profile() => _json('GET', '/profile');
  static Future<void> updateProfile(Map<String, dynamic> data) async => _json('PUT', '/profile', body: data);
  static Future<Map<String, dynamic>> crop(Map<String, dynamic> data) => _json('POST', '/crop-recommendation', body: data);
  static Future<Map<String, dynamic>> fertilizer(Map<String, dynamic> data) => _json('POST', '/fertilizer-recommendation', body: data);
  static Future<Map<String, dynamic>> irrigation(Map<String, dynamic> data) => _json('POST', '/irrigation-advice', body: data);
  static Future<Map<String, dynamic>> weather(double lat, double lon, String location) => _json('POST', '/weather', body: {'latitude': lat, 'longitude': lon, 'location': location});
  static Future<Map<String, dynamic>> chat(String message) => _json('POST', '/chat', body: {'message': message});
  static Future<Map<String, dynamic>> history() => _json('GET', '/history');

  static Future<List<dynamic>> notifications() async {
    final data = await _json('GET', '/notifications');
    return (data['items'] as List?) ?? <dynamic>[];
  }

  static Future<Map<String, dynamic>> disease(File file) async {
    final token = await ApiService.token();
    final request = http.MultipartRequest('POST', Uri.parse('$baseUrl/disease-detection'));
    if (token != null) request.headers['Authorization'] = 'Bearer $token';
    request.files.add(await http.MultipartFile.fromPath('file', file.path));
    final response = await request.send().timeout(const Duration(seconds: 45));
    final body = await response.stream.bytesToString();
    if (response.statusCode < 200 || response.statusCode >= 300) {
      try {
        throw Exception((jsonDecode(body)['detail'] ?? 'Image analysis failed').toString());
      } catch (e) {
        if (e is Exception) rethrow;
        throw Exception('Image analysis failed (${response.statusCode})');
      }
    }
    return jsonDecode(body) as Map<String, dynamic>;
  }
}
