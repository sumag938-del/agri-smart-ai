package com.agri.smartai

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
