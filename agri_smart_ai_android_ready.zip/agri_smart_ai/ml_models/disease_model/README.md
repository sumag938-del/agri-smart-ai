# Plant disease model
Place a labeled ImageFolder dataset here as `dataset/Crop|Disease/*.jpg`.
Run `python train.py --data dataset --epochs 8`. This creates `disease_model.keras` and `classes.txt`.
Copy/run from this folder or adjust paths as needed. FastAPI automatically loads the model when TensorFlow is installed; otherwise it uses the deterministic demo classifier.
