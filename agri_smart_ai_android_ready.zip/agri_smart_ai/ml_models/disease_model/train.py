"""Train a plant disease classifier from an ImageFolder dataset.
Expected layout: dataset/<class_name>/*.jpg where class_name is Crop|Disease.
Outputs disease_model.keras and classes.txt for the FastAPI inference service.
"""
import argparse, os
import tensorflow as tf

parser=argparse.ArgumentParser(); parser.add_argument('--data',default='dataset'); parser.add_argument('--epochs',type=int,default=8); args=parser.parse_args()
img_size=(224,224); batch=32
train=tf.keras.utils.image_dataset_from_directory(args.data,validation_split=.2,subset='training',seed=42,image_size=img_size,batch_size=batch)
val=tf.keras.utils.image_dataset_from_directory(args.data,validation_split=.2,subset='validation',seed=42,image_size=img_size,batch_size=batch)
classes=train.class_names
aug=tf.keras.Sequential([tf.keras.layers.RandomFlip('horizontal'),tf.keras.layers.RandomRotation(.08),tf.keras.layers.RandomZoom(.1)])
base=tf.keras.applications.MobileNetV2(input_shape=(*img_size,3),include_top=False,weights='imagenet'); base.trainable=False
model=tf.keras.Sequential([aug,tf.keras.layers.Rescaling(1/127.5,offset=-1),base,tf.keras.layers.GlobalAveragePooling2D(),tf.keras.layers.Dropout(.25),tf.keras.layers.Dense(len(classes),activation='softmax')])
model.compile(optimizer='adam',loss='sparse_categorical_crossentropy',metrics=['accuracy'])
model.fit(train,validation_data=val,epochs=args.epochs)
os.makedirs('.',exist_ok=True); model.save('disease_model.keras')
open('classes.txt','w',encoding='utf-8').write('\n'.join(classes))
print('Saved disease_model.keras and classes.txt')
