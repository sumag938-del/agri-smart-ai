import pandas as pd, joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
from pathlib import Path
root=Path(__file__).parent
df=pd.read_csv(root/'sample_crops.csv'); X=df.drop(columns='label'); y=df.label
Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.25,random_state=42,stratify=y)
model=RandomForestClassifier(n_estimators=250,random_state=42); model.fit(Xtr,ytr)
print('accuracy:',accuracy_score(yte,model.predict(Xte))); print(classification_report(yte,model.predict(Xte),zero_division=0))
joblib.dump(model,root/'crop_model.joblib'); print('saved',root/'crop_model.joblib')
