# AgriSmart AI – Project Diagrams

## System Architecture
```mermaid
flowchart LR
  A[Flutter Android App] -->|REST JSON / Multipart| B[FastAPI Backend]
  B --> C[JWT Auth]
  B --> D[AI Services]
  D --> D1[Crop ML - Scikit-learn]
  D --> D2[Disease CNN - TensorFlow/Keras]
  D --> D3[Fertilizer Engine]
  D --> D4[Irrigation Engine]
  D --> D5[AgriBot]
  B --> E[(SQLite / PostgreSQL / MySQL)]
  B --> F[Open-Meteo Weather API]
  G[Admin Dashboard] --> B
```

## Data Flow
```mermaid
flowchart TD
  U[Farmer] --> I[Flutter UI]
  I --> V[Input Validation]
  V --> API[FastAPI REST API]
  API --> ML[AI/ML Prediction]
  ML --> R[Recommendation / Result]
  API --> DB[(Database)]
  R --> I
  I --> U
```

## ER Diagram
```mermaid
erDiagram
  USERS ||--o| FARMER_PROFILES : has
  USERS ||--o{ CROP_RECOMMENDATIONS : creates
  USERS ||--o{ DISEASE_DETECTION : creates
  USERS ||--o{ FERTILIZER_RECOMMENDATIONS : creates
  USERS ||--o{ IRRIGATION_RECORDS : creates
  USERS ||--o{ WEATHER_RECORDS : receives
  USERS ||--o{ CHAT_HISTORY : creates
  USERS ||--o{ NOTIFICATIONS : receives
```

## Disease Detection Flow
```mermaid
flowchart LR
  A[Camera/Gallery] --> B[Image Validation]
  B --> C[Resize + Normalize]
  C --> D{Keras model available?}
  D -->|Yes| E[MobileNetV2 Classifier]
  D -->|No| F[Demo Classifier]
  E --> G[Crop + Disease + Confidence]
  F --> G
  G --> H[Symptoms / Causes / Treatment / Prevention]
  H --> I[Flutter Result Card]
```

## Crop Recommendation Flow
```mermaid
flowchart LR
  A[N,P,K,pH,Temperature,Humidity,Rainfall] --> B[Validation]
  B --> C[Scikit-learn Model]
  C --> D[Recommended Crop + Confidence]
  D --> E[Database History]
  D --> F[Flutter UI]
```
