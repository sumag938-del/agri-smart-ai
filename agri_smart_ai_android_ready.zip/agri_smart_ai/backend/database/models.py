from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, Text, DateTime, ForeignKey
from .db import Base

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    name = Column(String(120), nullable=False)
    email = Column(String(180), unique=True, index=True, nullable=True)
    phone = Column(String(30), unique=True, index=True, nullable=True)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(30), default="farmer")
    created_at = Column(DateTime, default=datetime.utcnow)

class FarmerProfile(Base):
    __tablename__ = "farmer_profiles"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True)
    location = Column(String(150), default="Hyderabad")
    farm_size = Column(Float, default=1.0)
    soil_type = Column(String(80), default="Loamy")
    main_crop = Column(String(100), default="Rice")

class CropRecommendation(Base):
    __tablename__ = "crop_recommendations"
    id = Column(Integer, primary_key=True); user_id = Column(Integer, ForeignKey("users.id"))
    n = Column(Float); p = Column(Float); k = Column(Float); ph = Column(Float)
    temperature = Column(Float); humidity = Column(Float); rainfall = Column(Float)
    crop = Column(String(100)); confidence = Column(Float); reason = Column(Text); created_at = Column(DateTime, default=datetime.utcnow)

class DiseaseDetection(Base):
    __tablename__ = "disease_detection"
    id = Column(Integer, primary_key=True); user_id = Column(Integer, ForeignKey("users.id"))
    crop = Column(String(100)); disease = Column(String(150)); confidence = Column(Float)
    symptoms = Column(Text); causes = Column(Text); treatment = Column(Text); prevention = Column(Text)
    image_name = Column(String(255)); created_at = Column(DateTime, default=datetime.utcnow)

class FertilizerRecommendation(Base):
    __tablename__ = "fertilizer_recommendations"
    id = Column(Integer, primary_key=True); user_id = Column(Integer, ForeignKey("users.id"))
    crop = Column(String(100)); soil_type = Column(String(80)); n = Column(Float); p = Column(Float); k = Column(Float); ph = Column(Float); stage = Column(String(80))
    fertilizer = Column(String(150)); guidance = Column(Text); reason = Column(Text); created_at = Column(DateTime, default=datetime.utcnow)

class IrrigationRecord(Base):
    __tablename__ = "irrigation_records"
    id = Column(Integer, primary_key=True); user_id = Column(Integer, ForeignKey("users.id"))
    soil_moisture = Column(Float); temperature = Column(Float); humidity = Column(Float); rainfall = Column(Float); crop = Column(String(100)); advice = Column(Text); created_at = Column(DateTime, default=datetime.utcnow)

class WeatherRecord(Base):
    __tablename__ = "weather_records"
    id = Column(Integer, primary_key=True); user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    location = Column(String(150)); temperature = Column(Float); humidity = Column(Float); rain_probability = Column(Float); wind_speed = Column(Float); condition = Column(String(100)); raw_json = Column(Text); created_at = Column(DateTime, default=datetime.utcnow)

class ChatHistory(Base):
    __tablename__ = "chat_history"
    id = Column(Integer, primary_key=True); user_id = Column(Integer, ForeignKey("users.id")); message = Column(Text); response = Column(Text); created_at = Column(DateTime, default=datetime.utcnow)

class Notification(Base):
    __tablename__ = "notifications"
    id = Column(Integer, primary_key=True); user_id = Column(Integer, ForeignKey("users.id")); title = Column(String(150)); body = Column(Text); read = Column(Integer, default=0); created_at = Column(DateTime, default=datetime.utcnow)
