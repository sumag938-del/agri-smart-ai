from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .database.db import Base, engine
from .routes import auth, features, profile, admin
Base.metadata.create_all(bind=engine)
app=FastAPI(title='AgriSmart AI API',version='1.0.0',description='AI-powered Smart Agriculture Assistant')
app.add_middleware(CORSMiddleware,allow_origins=['*'],allow_credentials=True,allow_methods=['*'],allow_headers=['*'])
app.include_router(auth.router); app.include_router(features.router); app.include_router(profile.router); app.include_router(admin.router)
@app.get('/')
def root(): return {'app':'AgriSmart AI','status':'running','docs':'/docs'}
@app.get('/health')
def health(): return {'status':'ok'}
