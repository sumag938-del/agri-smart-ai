import requests

def get_weather(lat:float, lon:float):
    url="https://api.open-meteo.com/v1/forecast"
    params={"latitude":lat,"longitude":lon,"current":"temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code","daily":"weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max","forecast_days":5,"timezone":"auto"}
    r=requests.get(url,params=params,timeout=10); r.raise_for_status(); d=r.json(); c=d["current"]
    code=c.get("weather_code",0)
    condition={0:"Clear",1:"Mainly clear",2:"Partly cloudy",3:"Overcast",45:"Fog",51:"Drizzle",61:"Rain",63:"Rain",65:"Heavy rain",80:"Rain showers",95:"Thunderstorm"}.get(code,"Mixed")
    daily=d["daily"]
    forecast=[]
    for i,date in enumerate(daily["time"]): forecast.append({"date":date,"max":daily["temperature_2m_max"][i],"min":daily["temperature_2m_min"][i],"rain_probability":daily["precipitation_probability_max"][i],"weather_code":daily["weather_code"][i]})
    return {"temperature":c["temperature_2m"],"humidity":c["relative_humidity_2m"],"wind_speed":c["wind_speed_10m"],"rain_probability":forecast[0]["rain_probability"],"condition":condition,"forecast":forecast}
