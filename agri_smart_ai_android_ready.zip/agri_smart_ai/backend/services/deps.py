from fastapi import Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from ..database.db import get_db
from ..database.models import User
from .auth import decode_token
security = HTTPBearer()

def current_user(credentials: HTTPAuthorizationCredentials = Depends(security), db: Session = Depends(get_db)):
    uid = decode_token(credentials.credentials)
    user = db.get(User, uid) if uid else None
    if not user: raise HTTPException(401, "Invalid or expired token")
    return user
