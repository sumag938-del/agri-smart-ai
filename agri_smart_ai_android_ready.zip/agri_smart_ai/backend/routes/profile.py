from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from ..database.db import get_db
from ..database.models import User, FarmerProfile
from ..services.deps import current_user
router=APIRouter()
class ProfileIn(BaseModel): location:str='Hyderabad'; farm_size:float=Field(default=1,ge=0); soil_type:str='Loamy'; main_crop:str='Rice'
@router.get('/profile')
def get_profile(u=Depends(current_user),db:Session=Depends(get_db)):
    p=db.query(FarmerProfile).filter_by(user_id=u.id).first(); return {'name':u.name,'email':u.email,'phone':u.phone,'location':p.location,'farm_size':p.farm_size,'soil_type':p.soil_type,'main_crop':p.main_crop}
@router.put('/profile')
def update_profile(x:ProfileIn,u=Depends(current_user),db:Session=Depends(get_db)):
    p=db.query(FarmerProfile).filter_by(user_id=u.id).first();
    for k,v in x.model_dump().items(): setattr(p,k,v)
    db.commit(); return {'message':'Profile updated'}
