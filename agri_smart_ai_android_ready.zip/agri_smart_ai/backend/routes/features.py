import os, json
from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from ..database.db import get_db
from ..database.models import *
from ..services.deps import current_user
from ..ai.crop import recommend as crop_recommend
from ..ai.disease import predict as disease_predict
from ..ai.fertilizer import recommend as fert_recommend
from ..ai.irrigation import advise as irrigation_advise
from ..ai.chatbot import reply as bot_reply
from ..services.weather import get_weather
router=APIRouter()
class CropIn(BaseModel): n:float=Field(ge=0,le=500); p:float=Field(ge=0,le=500); k:float=Field(ge=0,le=500); ph:float=Field(ge=0,le=14); temperature:float; humidity:float=Field(ge=0,le=100); rainfall:float=Field(ge=0,le=5000); location:str=''
class FertIn(BaseModel): crop:str; soil_type:str; n:float=Field(ge=0); p:float=Field(ge=0); k:float=Field(ge=0); ph:float=Field(ge=0,le=14); stage:str
class IrrIn(BaseModel): soil_moisture:float=Field(ge=0,le=100); temperature:float; humidity:float=Field(ge=0,le=100); rainfall:float=Field(ge=0); crop:str
class ChatIn(BaseModel): message:str=Field(min_length=1,max_length=2000)
class WeatherIn(BaseModel): latitude:float=Field(ge=-90,le=90); longitude:float=Field(ge=-180,le=180); location:str=''
@router.post('/crop-recommendation')
def crop(x:CropIn,u=Depends(current_user),db:Session=Depends(get_db)):
    c,conf,reason=crop_recommend(x.n,x.p,x.k,x.ph,x.temperature,x.humidity,x.rainfall); db.add(CropRecommendation(user_id=u.id,n=x.n,p=x.p,k=x.k,ph=x.ph,temperature=x.temperature,humidity=x.humidity,rainfall=x.rainfall,crop=c,confidence=conf,reason=reason)); db.commit(); return {'crop':c,'confidence':conf,'reason':reason}
@router.post('/disease-detection')
async def disease(file:UploadFile=File(...),u=Depends(current_user),db:Session=Depends(get_db)):
    if file.content_type not in ['image/jpeg','image/png','image/webp']: raise HTTPException(400,'Only JPG, PNG or WEBP images are allowed')
    data=await file.read()
    if len(data)>8*1024*1024: raise HTTPException(413,'Image must be under 8 MB')
    out=disease_predict(data); out['image_name']=file.filename
    db.add(DiseaseDetection(user_id=u.id,**{k:out[k] for k in ['crop','disease','confidence','symptoms','causes','treatment','prevention']},image_name=file.filename)); db.commit(); return out
@router.post('/fertilizer-recommendation')
def fertilizer(x:FertIn,u=Depends(current_user),db:Session=Depends(get_db)):
    f,r,g=fert_recommend(**x.model_dump()); db.add(FertilizerRecommendation(user_id=u.id,**x.model_dump(),fertilizer=f,reason=r,guidance=g)); db.commit(); return {'fertilizer':f,'reason':r,'guidance':g}
@router.post('/irrigation-advice')
def irrigation(x:IrrIn,u=Depends(current_user),db:Session=Depends(get_db)):
    a=irrigation_advise(**x.model_dump()); db.add(IrrigationRecord(user_id=u.id,**x.model_dump(),advice=a)); db.commit(); return {'advice':a}
@router.post('/weather')
def weather(x:WeatherIn,u=Depends(current_user),db:Session=Depends(get_db)):
    out=get_weather(x.latitude,x.longitude); db.add(WeatherRecord(user_id=u.id,location=x.location,temperature=out['temperature'],humidity=out['humidity'],rain_probability=out['rain_probability'],wind_speed=out['wind_speed'],condition=out['condition'],raw_json=json.dumps(out))); db.commit(); return out
@router.post('/chat')
def chat(x:ChatIn,u=Depends(current_user),db:Session=Depends(get_db)):
    ans=bot_reply(x.message); db.add(ChatHistory(user_id=u.id,message=x.message,response=ans)); db.commit(); return {'response':ans}
@router.get('/history')
def history(u=Depends(current_user),db:Session=Depends(get_db)):
    def clean(obj, fields): return [{f:getattr(x,f) for f in fields} for x in obj]
    return {
      'disease': clean(db.query(DiseaseDetection).filter_by(user_id=u.id).order_by(DiseaseDetection.created_at.desc()).limit(20), ['crop','disease','confidence','symptoms','causes','treatment','prevention','created_at']),
      'crop': clean(db.query(CropRecommendation).filter_by(user_id=u.id).order_by(CropRecommendation.created_at.desc()).limit(20), ['crop','confidence','reason','created_at']),
      'fertilizer': clean(db.query(FertilizerRecommendation).filter_by(user_id=u.id).order_by(FertilizerRecommendation.created_at.desc()).limit(20), ['crop','fertilizer','reason','guidance','created_at']),
      'irrigation': clean(db.query(IrrigationRecord).filter_by(user_id=u.id).order_by(IrrigationRecord.created_at.desc()).limit(20), ['crop','advice','created_at']),
      'chat': clean(db.query(ChatHistory).filter_by(user_id=u.id).order_by(ChatHistory.created_at.desc()).limit(20), ['message','response','created_at'])}
@router.get('/notifications')
def notifications(u=Depends(current_user),db:Session=Depends(get_db)):
    return {'items':[{'id':x.id,'title':x.title,'body':x.body,'read':x.read,'created_at':x.created_at} for x in db.query(Notification).filter_by(user_id=u.id).order_by(Notification.created_at.desc()).limit(30)]}
