from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..database.db import get_db
from ..database.models import *
from ..services.deps import current_user
router=APIRouter(prefix='/admin')
def admin(u=Depends(current_user)):
    if u.role!='admin': raise HTTPException(403,'Admin access required')
    return u
@router.get('/stats')
def stats(db:Session=Depends(get_db),_=Depends(admin)):
    return {'farmers':db.query(User).filter_by(role='farmer').count(),'disease_detections':db.query(DiseaseDetection).count(),'crop_recommendations':db.query(CropRecommendation).count(),'fertilizer_recommendations':db.query(FertilizerRecommendation).count(),'chat_messages':db.query(ChatHistory).count()}
@router.get('/farmers')
def farmers(db:Session=Depends(get_db),_=Depends(admin)):
    return [{'id':u.id,'name':u.name,'email':u.email,'phone':u.phone,'created_at':u.created_at} for u in db.query(User).all()]
