from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy.orm import Session
from ..database.db import get_db
from ..database.models import User, FarmerProfile
from ..services.auth import hash_password, verify_password, create_token
router=APIRouter()
class Register(BaseModel): name:str=Field(min_length=2,max_length=120); email:EmailStr|None=None; phone:str|None=None; password:str=Field(min_length=6,max_length=128)
class Login(BaseModel): identifier:str; password:str
@router.post('/register')
def register(x:Register,db:Session=Depends(get_db)):
    if not x.email and not x.phone: raise HTTPException(400,'Email or phone is required')
    q=db.query(User).filter((User.email==x.email) | (User.phone==x.phone)).first()
    if q: raise HTTPException(409,'Account already exists')
    u=User(name=x.name,email=x.email,phone=x.phone,password_hash=hash_password(x.password)); db.add(u); db.commit(); db.refresh(u)
    db.add(FarmerProfile(user_id=u.id)); db.commit()
    return {'access_token':create_token(u.id),'user':{'id':u.id,'name':u.name,'email':u.email,'phone':u.phone}}
@router.post('/login')
def login(x:Login,db:Session=Depends(get_db)):
    u=db.query(User).filter((User.email==x.identifier)|(User.phone==x.identifier)).first()
    if not u or not verify_password(x.password,u.password_hash): raise HTTPException(401,'Invalid credentials')
    return {'access_token':create_token(u.id),'user':{'id':u.id,'name':u.name,'email':u.email,'phone':u.phone}}
