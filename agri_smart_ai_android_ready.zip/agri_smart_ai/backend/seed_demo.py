from database.db import SessionLocal, Base, engine
from database.models import User, FarmerProfile, Notification
from services.auth import hash_password
Base.metadata.create_all(bind=engine)
db=SessionLocal()
email='farmer@demo.local'
u=db.query(User).filter_by(email=email).first()
if not u:
    u=User(name='Demo Farmer',email=email,password_hash=hash_password('Farmer@123'),role='farmer'); db.add(u); db.commit(); db.refresh(u); db.add(FarmerProfile(user_id=u.id)); db.add(Notification(user_id=u.id,title='Welcome to AgriSmart AI',body='Complete your farm profile to improve recommendations.')); db.commit()
print('Demo login:',email,'Farmer@123')
db.close()
