def reply(q: str):
    x=q.lower()
    if any(w in x for w in ["yellow", "yellowing"]): return "Yellow leaves can come from nitrogen deficiency, water stress, pests or disease. Check the lower/older leaves, soil moisture and the underside of leaves; a clear photo can help narrow it down."
    if "irrigat" in x or "water" in x: return "Irrigate based on soil moisture, crop stage and rain forecast. If soil moisture is low and no rain is expected, water gradually and avoid waterlogging."
    if "fertilizer" in x or "npk" in x: return "Use a soil test and crop stage to guide fertilizer. Avoid applying more than the label or local recommendation; excessive nitrogen can increase pest and disease risk."
    if "crop" in x and ("soil" in x or "suitable" in x): return "Tell me your N, P, K, pH, temperature, humidity and rainfall values. I can rank suitable crops, then you should validate the choice with local agricultural guidance."
    if "disease" in x or "leaf" in x: return "Upload a clear photo of the affected leaf in Disease Detection. For best results, photograph the whole leaf and close-up symptoms in good daylight."
    if "weather" in x or "rain" in x: return "Use the Weather screen for current conditions and a 5-day forecast. Rain probability is especially useful before irrigation or spraying."
    return "I’m AgriBot. I can help with crops, disease symptoms, irrigation, fertilizer, soil and weather. Ask me a specific farm question for a more useful answer."
