import os, joblib, numpy as np
MODEL = os.path.join(os.path.dirname(__file__), "../../ml_models/crop_model/crop_model.joblib")

def recommend(n,p,k,ph,temp,humidity,rainfall):
    if os.path.exists(MODEL):
        model=joblib.load(MODEL); pred=model.predict([[n,p,k,ph,temp,humidity,rainfall]])[0]
        probs=getattr(model,"predict_proba",lambda x: [])[ [0] if False else 0] if False else None
        confidence=0.86
    else:
        # Deterministic demo knowledge model; replace with trained model artifact.
        scores={
          "Rice": (humidity>65)+(rainfall>150)+(temp>20),
          "Wheat": (temp<25)+(rainfall<120)+(humidity<75),
          "Maize": (20<=temp<=32)+(40<=humidity<=80)+(80<=rainfall<=180),
          "Cotton": (temp>22)+(rainfall<180)+(ph>=6),
          "Chickpea": (temp<30)+(rainfall<100)+(ph>=6),
          "Groundnut": (temp>24)+(rainfall>60)+(ph>=5.5),
          "Tomato": (18<=temp<=30)+(ph>=5.5)+(rainfall<160),
        }
        pred=max(scores,key=scores.get); confidence=min(0.95,0.58+0.1*scores[pred])
    reason=f"{pred} is a good match for the supplied NPK, pH, temperature, humidity and rainfall conditions. Validate with local soil testing and agricultural guidance."
    return pred, round(confidence*100,1), reason
