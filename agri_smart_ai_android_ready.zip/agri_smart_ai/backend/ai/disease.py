"""Plant disease inference.
If ml_models/disease_model/disease_model.keras exists and TensorFlow is installed,
use the real Keras classifier. Otherwise use a deterministic demo classifier so
the end-to-end application remains runnable for a college demonstration.
"""
import io, os, hashlib
from PIL import Image

MODEL_PATH = os.path.join(os.path.dirname(__file__), '../../ml_models/disease_model/disease_model.keras')
CLASS_NAMES_PATH = os.path.join(os.path.dirname(__file__), '../../ml_models/disease_model/classes.txt')


def _keras_predict(image_bytes: bytes):
    try:
        import numpy as np
        import tensorflow as tf
        if not os.path.exists(MODEL_PATH): return None
        model = tf.keras.models.load_model(MODEL_PATH)
        image = Image.open(io.BytesIO(image_bytes)).convert('RGB').resize((224, 224))
        arr = np.asarray(image, dtype='float32') / 255.0
        probs = model.predict(arr[None, ...], verbose=0)[0]
        idx = int(np.argmax(probs)); confidence = float(probs[idx]) * 100
        classes = [x.strip() for x in open(CLASS_NAMES_PATH, encoding='utf-8') if x.strip()] if os.path.exists(CLASS_NAMES_PATH) else []
        label = classes[idx] if idx < len(classes) else f'Class {idx}'
        crop, disease = label.split('|', 1) if '|' in label else ('Unknown crop', label)
        return {'crop': crop, 'disease': disease, 'confidence': round(confidence, 1), 'demo': False}
    except Exception:
        return None


def predict(image_bytes: bytes):
    real = _keras_predict(image_bytes)
    if real:
        details = {
            'symptoms': 'See the classifier label and confirm with a local agronomist or extension officer.',
            'causes': 'Disease cause depends on crop, pathogen pressure and field conditions.',
            'treatment': 'Use locally approved integrated disease-management guidance.',
            'prevention': 'Use healthy planting material, field sanitation and avoid prolonged leaf wetness.'}
        return {**real, **details}

    img = Image.open(io.BytesIO(image_bytes)).convert('RGB').resize((128,128))
    digest = hashlib.sha256(img.tobytes()).digest()[0]
    classes=[
      ('Tomato','Tomato Leaf Blight','Brown/black lesions and yellowing leaves.','Fungal infection favored by leaf wetness and poor airflow.','Remove affected leaves, improve airflow and use locally approved fungicide if advised.','Avoid overhead irrigation, sanitize tools and remove infected debris.'),
      ('Rice','Rice Leaf Blast','Spindle-shaped lesions with gray centers.','Fungal pressure can rise under humid conditions and excess nitrogen.','Consult local extension guidance for an approved blast management program.','Use healthy seed, balanced nutrition and field sanitation.'),
      ('Cotton','Cotton Leaf Spot','Small circular spots that may merge as disease progresses.','Leaf-spot pressure can increase with humidity and wet foliage.','Remove severely affected material and follow locally approved crop-protection guidance.','Maintain field sanitation and avoid prolonged leaf wetness.')]
    c=classes[digest%len(classes)]
    return {'crop':c[0],'disease':c[1],'confidence':round(78+(digest%18),1),'symptoms':c[2],'causes':c[3],'treatment':c[4],'prevention':c[5],'demo':True}
