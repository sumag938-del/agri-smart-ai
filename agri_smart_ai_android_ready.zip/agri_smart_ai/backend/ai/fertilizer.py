def recommend(crop, soil_type, n,p,k,ph,stage):
    low=[]
    if n<50: low.append("nitrogen")
    if p<35: low.append("phosphorus")
    if k<35: low.append("potassium")
    if low:
        names={"nitrogen":"a nitrogen source such as urea", "phosphorus":"a phosphorus source such as DAP/SSP", "potassium":"a potassium source such as MOP"}
        fertilizer=" + ".join(names[x] for x in low)
        reason="Low measured " + ", ".join(low) + " levels are driving the recommendation."
    else:
        fertilizer="Balanced NPK fertilizer / compost according to crop stage"
        reason="The supplied NPK values are not strongly deficient; focus on crop-stage nutrition and soil-test guidance."
    guidance=f"For {crop} at the {stage} stage, apply only according to a local soil-test recommendation and the product label; split nitrogen applications where appropriate and irrigate after application when suitable. Avoid over-fertilizing."
    return fertilizer,reason,guidance
