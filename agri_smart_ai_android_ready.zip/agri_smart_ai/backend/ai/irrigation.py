def advise(moisture,temp,humidity,rainfall,crop):
    if rainfall>=60: return "Rain expected – avoid unnecessary irrigation. Recheck soil moisture after rainfall."
    if moisture<30: return "Water required. Irrigate gradually and recheck soil moisture; avoid runoff or waterlogging."
    if moisture<50 and temp>30: return "Light irrigation is advisable soon, especially during hot conditions."
    return "Watering can be delayed. Monitor soil moisture and the crop's growth stage."
