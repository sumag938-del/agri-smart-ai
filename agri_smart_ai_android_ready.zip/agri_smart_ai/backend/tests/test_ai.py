from backend.ai.crop import recommend
from backend.ai.fertilizer import recommend as fert
from backend.ai.irrigation import advise

def test_crop_demo():
    crop, confidence, reason = recommend(70,40,40,6.5,28,70,120)
    assert crop and 0 <= confidence <= 100 and reason

def test_fertilizer():
    fertilizer, reason, guidance = fert('Rice','Loamy',20,20,20,6.5,'Vegetative')
    assert fertilizer and reason and guidance

def test_irrigation():
    assert 'Water' in advise(20,31,65,0,'Rice')
